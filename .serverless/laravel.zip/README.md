# mem-vision-serverless

## デプロイ方法
参考：https://forestbook-freelance.com/2021/03/12/serverless-framework-aws/
serverless deploy --aws-profile mem-vision-dev

## 初期アクセス
https://a9k7jzov9f.execute-api.us-east-1.amazonaws.com
