<template>
    <div>
        <h1>会員情報詳細</h1>
    </div>
</template>
